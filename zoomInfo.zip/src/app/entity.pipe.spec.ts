import { EntityPipe } from './entity.pipe';

describe('EntityPipe', () => {
  it('create an instance', () => {
    const pipe = new EntityPipe();
    expect(pipe).toBeTruthy();
  });
});
