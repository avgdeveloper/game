import { Question } from './question';
export interface HttpRes {

  response_code: number;
  results: Question[]
}
