export interface Question {
  // {"category":"Geography","type":"multiple","difficulty":"medium","question":"What is the capital of the State of Washington, United States?","correct_answer":"Olympia","incorrect_answers":["Washington D.C.","Seattle","Yukon"]}
  category: string;
  type: string;
  difficulty: string;
  question: string;
  correct_answer: string;
  incorrect_answers: string[];
}
