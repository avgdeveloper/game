import { Question } from './../models/question';
import { HttpClient } from '@angular/common/http';
import { HttpRes } from './../models/http-res';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { templateJitUrl } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class QuestionsService {

  constructor(private http: HttpClient) { }

  getQuestions(): Observable<HttpRes> {
    return this.http.get<HttpRes>('https://opentdb.com/api.php?amount=10&type=multiple');

  }

}
